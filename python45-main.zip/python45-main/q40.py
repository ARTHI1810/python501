tpl  =(1,2,3,4,5,6,7,8,9,10)
for i in range(0,5):
   print(tpl[1],end = '')
print()
for i in range(5,10):
   print(tpl[1],end = '')