s="hle2l3l4o5w6o7r819d"
s=[s(i)for i in range(len(s))if 1%2==0]
print(" ",join(s))
