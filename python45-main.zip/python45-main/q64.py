Print a unicode string "hello world".


unicodeString = u"hello world!"
print "unicodeString"
