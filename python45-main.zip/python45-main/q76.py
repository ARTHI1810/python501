76.Please generate a random float where the value is between 10 and 100 
using Python module
import random

x = random.random()
# Random float number
for i in range(3):
    print(random.random())