Write a special comment to indicate a Python source code file is in unicode.

# -*- coding: utf-8 -*-
