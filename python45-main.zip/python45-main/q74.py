Please write a program which accepts basic mathematic expression from console and print the evaluation result.

Example: If the following n is given as input to the program:

expression = input()
ans = eval(expression)
print(ans)

