n=int(input())
divBy7=[i for i in range (0,n)if(i%7==0)]
print(divBy7)
def divchecker(n):
    for i in range(n):
       if i%7==0:
        
        print(value)
