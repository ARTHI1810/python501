n=25
print(type(n))
print(n)
con_num=str(n)
print(type(con_num))
print(con_num)
