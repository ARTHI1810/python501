def add_num(a,b):
    sum=a+b;
    return sum;
num1=25
num2=55
print("the sum is",add_num(num1,num2))
