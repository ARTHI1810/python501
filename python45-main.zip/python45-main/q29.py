29. Define a function that can accept two strings as input and concatenate 
them and then print it in console


sum = lambda s1,s2 : s1 + s2
print(sum("10","45"))      
