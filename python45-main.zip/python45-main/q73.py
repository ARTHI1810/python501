Please write assert statements to verify that every number in the list [2,4,6,8] is even.

li = [2,4,6,8]
for i in li:
    assert i%2==0
