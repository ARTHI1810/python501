conv=lambda x:str(x)
n=conv(10)
print(n)
print(type(n))
